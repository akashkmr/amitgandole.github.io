

self.addEventListener('fetch', function(event) {
  if (event.request.url == 'https://amitgandole.github.io/') {
    console.info('responding to everything fetch with Service Worker! 🤓');
    event.respondWith(fetch(event.request).catch(function(e) {
      let out = "This page can't be offline!!!";
      return new Response(JSON.stringify(out));
    }));
    return;
  }

  event.respondWith(
    caches.match(event.request).then(function(response) {
      return response || fetch(event.request);
    })
  );
});

//NOT WORKING STILL
self.addEventListener('push', function(event) {
  event.waitUntil(
    self.registration.showNotification('Got Push?', {
      body: 'Push Message received'
   }));
});


self.addEventListener('install', function(e) {
  e.waitUntil(
    caches.open('the-magic-cache').then(function(cache) {
      return cache.addAll([
//Add the pages you want offline.
        '/',
        '/index.html',
        '/aa.html',
        '/manifest.json',
        '/site.js'
      
      ]);
    })
  );
});

